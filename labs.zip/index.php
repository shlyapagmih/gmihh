<?php
require('header.inc');
?>
<?php
require('footer.inc');
?>
